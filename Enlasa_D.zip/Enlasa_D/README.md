# Enlasa_D
#Proyecto formativo 
#Titulación: ADSI

-Aplicación web para la empresa Enlasa

-La aplicación web va a realizarse para una empresa de seguros.

Framework: Django

Desarrolladores:
-Gissell Tatiana Matta
-Maria Elvira Cujar
-Sofía Canizales Lezama
-Santiago Bénitez
-Santiago Sáez Cortes


